define([
    "hr/hr"
], function(hr) {
	// Load templates using direct text content
    hr.Resources.addNamespace("templates", {
        loader: "text"
    });
    
    return {}
});