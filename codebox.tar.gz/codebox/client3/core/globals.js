define(['require'], function (require) {
    window.codebox = {
        'require': require
    };

    return window.codebox;
});