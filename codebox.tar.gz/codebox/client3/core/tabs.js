define([
    'views/tabs/manager'
], function (TabsView) {
    var tabs = new TabsView();
    return tabs;
});