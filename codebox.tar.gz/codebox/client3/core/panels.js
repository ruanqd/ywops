define([
    'views/panels/manager'
], function (PanelsView) {
    var panels = new PanelsView();
    return panels;
});