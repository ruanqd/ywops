define([
    'hr/hr',
    'utils/url',
    'utils/dialogs',
    'utils/alerts',
    'utils/loading',
    'views/grid',
    'text!resources/templates/main.html',
    'core/box',
    'core/session',
    'core/addons',
    'core/box',
    'core/files',
	'models/command',
    'core/commands/toolbar',
    'core/commands/menu',
    'core/commands/statusbar',
    'core/commands/palette',
    'core/tabs',
    'core/panels',
    'core/operations',
    'core/localfs',
    'core/themes',
    'core/search/commands',
    'core/search/files',
    'core/search/tags',
    'core/search/addons',
    'core/search/code'
], function (hr, url, dialogs, alerts, loading, GridView, templateFile,
box, session, addons, box, files,Command, commands, menu, statusbar, palette, tabs, panels, operations, localfs, themes) {

    // Define base application
    var Application = hr.Application.extend({
        name: "Codebox",
        template: templateFile,
        metas: {
            "robots": "noindex, nofollow",
            "description": "Cloud IDE on a box.",
            "apple-mobile-web-app-capable": "yes",
            "apple-mobile-web-app-status-bar-style": "black",
            "viewport": "width=device-width, initial-scale=1, user-scalable=no"
        },
        links: {
            "icon": hr.Urls.static("images/icons/32.png"),
            "apple-touch-icon": hr.Urls.static("images/icons/ios.png")
        },
        events: {
            "click .cb-login .login-box #login-submit": "actionLoginBox"
        },

        // Constructor
           initialize: function() {
            Application.__super__.initialize.apply(this, arguments);
            this._autologin = true;
            this.loginError = null;

            // Init base grid for UI
            this.grid = new GridView({
                columns: 1000
            });
		            // Add tabs
            this.grid.addView(tabs,{
				 width: 100
			});
			
            // Add lateral bar: panels and operations
  
            // Add operations
            operations.on("add remove reset", function() {
                setTimeout(function() {
                    panels.$el.css("bottom", operations.$el.height());
                }, 200);
            });



            // Title changed
            box.on("change:name", function() {
                this.title(box.get("name"));
            }, this);

            return this;
        },

        // Template rendering context
        templateContext: function() {
            return {
                'email': hr.Cookies.get("email"),
                'token': hr.Cookies.get("token"),
                'loginError': this.loginError
            };
        },

        // Render the application
        render: function() {
            var email = "guest";
            var password = "guest";

            if (!box.isAuth() && ((email && password) || (email && box.get("public"))) && this._autologin) {
                this.doLogin(email, password);
                return;
            }
            return Application.__super__.render.apply(this, arguments);
        },

        // Finish rendering
        finish: function() {
            var that = this;
			
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};
var jid= getUrlParameter('jid');

            if (box.isAuth()) {
      		
                // Add grid
                this.grid.$el.appendTo(this.$(".cb-body"));

                // Add palette
                palette.$el.appendTo(this.$(".cb-body"));
                palette.render();

                // Load addons
                loading.show(addons.loadAll()).fail(function(err) {
                    return dialogs.alert("err");
                })
                .fin(themes.init)
                .fin(function() {
                    // Load new addons
                    addons.on("add", function(addon) {
                        addon.load();
                    });
                    // Check update
                   // hr.Offline.checkUpdate();

                    // Trigger event that app is ready
                    that.trigger("ready");

                    // Open new file if not files opened by addons and no restored tabs
                   tabs.restoreTabs()
                    .then(function(_n) {
                        if (files.active.size() == 0 && _n == 0){	
							var sURLVariables = jid.split('_',4),
							sParameterName,
							i;
							var jobid=sURLVariables[0];
							for (i = 1; i < sURLVariables.length; i++) {
								sParameterName = sURLVariables[i];
								sParameterName =jobid+"-"+sParameterName;
								Command.run("terminal.open", null, {
										'cwd': "jid/"+sParameterName
								});
							}
							tabs.splitSection( );
							return;						
							//	
						}
                    });
                });
            }
            return Application.__super__.finish.apply(this, arguments);
        },

        // Login to box
        actionLoginBox: function(e) {
            var that = this;
            if (e) {
                e.preventDefault();
            }

            var email = "guest";
            var password = "guest";

            this.doLogin(email, password);
        },

        // Do login
        doLogin: function(email, password) {
            var that = this;

            // If public: generate a random password
            if (box.get("public")) {
               // password = Math.random().toString(36).substring(8);
            }

            // Clear errors
            this.$(".login-box .form-group").removeClass("has-error");

            // No email
            if (!email) {
                //this.$(".login-box #login-email").parent(".form-group").addClass("has-error");
                //return Q.reject(new Error("No email"));
            }

            // No password
            if (!password) {
               // this.$(".login-box #login-token").parent(".form-group").addClass("has-error");
                //return Q.reject(new Error("No password"));
            }

            return session.start(email, password).then(function() {
                hr.Cookies.set("email", "guest");
                hr.Cookies.set("token", "guest");

                that.render();
            }).fail(function(err) {
                that._autologin = false;
                that.loginError = err;

                loading.stop();
                that.render();
            });
        },

        // Toggle mode
        toggleMode: function(mode, st) {
            $("#codebox").toggleClass("mode-"+mode, st);
            st = this.hasMode(mode);
            $(".cb-active-mode-"+mode).toggleClass("active", st);
            $(".cb-inactive-mode-"+mode).toggleClass("active", !st);
        },
        hasMode: function(mode, st) {
            return $("#codebox").hasClass("mode-"+mode);
        }
    });

    var app = new Application();
    return app;
});
