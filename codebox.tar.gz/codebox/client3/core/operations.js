define([
    'views/operations/manager'
], function (Operations) {
    var operations = new Operations();
    return operations;
});